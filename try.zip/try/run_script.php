<?php
// run_script.php

$command = 'C:\\xampp\\htdocs\\try\\CHECK_CAMERA.py'; // Path to your script

// Execute the script
exec($command, $output, $return_var);

if ($return_var === 0) {
    echo 'Success';
} else {
    echo 'Error';
}
?>
