<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monthly Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: lightblue;
        .chart-container {
            width: 80%;
            margin: 0 auto;
        }
        .back-button {
            position: absolute;
            top: 10px;
            left: 10px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
        .info-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 20px;
        }
        .info-box {
            font-size: 18px;
            font-weight: bold;
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
        }
        table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
            text-align: center;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        .total-row {
            font-weight: bold;
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <!-- Back Button -->
    <a href="http://localhost/try/model.html" class="back-button">Back</a>

    <h1 style="text-align: center;">Monthly Report</h1>

<!-- Dropdown for selecting report type -->
<form method="GET" action="http://localhost/try/monthly.php" style="text-align: center; margin-bottom: 20px;">
    <label for="reportType">Report Type:</label>
    <select name="reportType" id="reportType" onchange="navigateToReport()">
        <option value="daily" >Daily</option>
        <option value="weekly">Weekly</option>
        <option value="monthly"selected>Monthly</option>
    </select>
    <button type="submit" id="navigateButton">Enter</button>
</form>

<script>
    function navigateToReport() {
        const reportType = document.getElementById('reportType').value;
        const button = document.getElementById('navigateButton');

        if (reportType === 'daily') {
            // Redirect to daily.php
            button.form.action = "http://localhost/try/daily.php";
        } else if (reportType === 'weekly') {
            // Redirect to weekly.php
            button.form.action = "http://localhost/try/weekly.php";
        } else if (reportType === 'monthly') {
            // Redirect to monthly.php
            button.form.action = "http://localhost/try/monthly.php";
        }
    }
</script>

    <!-- Dropdown for selecting year and month -->
    <form method="POST" style="text-align: center; margin-bottom: 20px;">
        <label for="year">Year:</label>
        <select name="year" id="year">
            <option value="2024" <?php echo isset($_POST['year']) && $_POST['year'] == '2024' ? 'selected' : ''; ?>>2024</option>
            <option value="2025" <?php echo isset($_POST['year']) && $_POST['year'] == '2025' ? 'selected' : ''; ?>>2025</option>
        </select>

        <label for="month">Month:</label>
        <select name="month" id="month">
            <option value="01" <?php echo isset($_POST['month']) && $_POST['month'] == '01' ? 'selected' : ''; ?>>01</option>
            <option value="12" <?php echo isset($_POST['month']) && $_POST['month'] == '12' ? 'selected' : ''; ?>>12</option>
        </select>

        <button type="submit" name="submit">Generate Report</button>
    </form>

    <div class="chart-container">
        <canvas id="monthlyChart"></canvas>
    </div>

    <div id="infoContainer" class="info-container"></div>

    <?php
    // Database connection
    $conn = new mysqli("localhost", "root", "", "tollcollectionsystem");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the selected year and month from the form, default to current year and month
    $year = isset($_POST['year']) ? $_POST['year'] : date('Y');
    $month = isset($_POST['month']) ? $_POST['month'] : date('m');

    // Fetch daily report data for the selected month and year
    $sql = "SELECT DATE(d.timestamp) AS day, 
                       COUNT(d.detection_id) AS vehicle_count, 
                       SUM(CASE WHEN c.class_id = 'Class 1' THEN 1 ELSE 0 END) AS class_1_count,
                       SUM(CASE WHEN c.class_id = 'Class 2' THEN 1 ELSE 0 END) AS class_2_count,
                       SUM(CASE WHEN c.class_id = 'Class 3' THEN 1 ELSE 0 END) AS class_3_count,
                       SUM(CASE WHEN c.class_id = 'Class 4' THEN 1 ELSE 0 END) AS class_4_count,
                       SUM(CASE WHEN c.class_id = 'Class 5' THEN 1 ELSE 0 END) AS class_5_count
                FROM detection d
                INNER JOIN class c ON d.class_id = c.class_id
                WHERE MONTH(d.timestamp) = $month AND YEAR(d.timestamp) = $year
                GROUP BY DATE(d.timestamp)
                ORDER BY day";

    $result = $conn->query($sql);

    $days = [];
    $class1Counts = [];
    $class2Counts = [];
    $class3Counts = [];
    $class4Counts = [];
    $class5Counts = [];
    $classPrices = [
        'Class 1' => 1,
        'Class 2' => 4.6,
        'Class 3' => 6.9,
        'Class 4' => 1.2,
        'Class 5' => 1.6
    ];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $days[] = $row['day'];
            $class1Counts[] = $row['class_1_count'];
            $class2Counts[] = $row['class_2_count'];
            $class3Counts[] = $row['class_3_count'];
            $class4Counts[] = $row['class_4_count'];
            $class5Counts[] = $row['class_5_count'];
        }
    } else {
        echo "<p style='text-align:center;'>No data available for this month.</p>";
    }

    $conn->close();

    // Calculate total price for each class type
    $classTotals = [
        'Class 1' => array_sum($class1Counts) * $classPrices['Class 1'],
        'Class 2' => array_sum($class2Counts) * $classPrices['Class 2'],
        'Class 3' => array_sum($class3Counts) * $classPrices['Class 3'],
        'Class 4' => array_sum($class4Counts) * $classPrices['Class 4'],
        'Class 5' => array_sum($class5Counts) * $classPrices['Class 5']
    ];

    // Calculate total vehicles and total price
    $totalVehicles = array_sum($class1Counts) + array_sum($class2Counts) + array_sum($class3Counts) + array_sum($class4Counts) + array_sum($class5Counts);
    $totalPrice = $classTotals['Class 1'] + $classTotals['Class 2'] + $classTotals['Class 3'] + $classTotals['Class 4'] + $classTotals['Class 5'];
    ?>

    <!-- Displaying the summary table -->
    <table>
        <thead>
            <tr>
                <th>Class Type</th>
                <th>Class Price (RM)</th>
                <th>Total Vehicles</th>
                <th>Total Price (RM)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Class 1</td>
                <td><?php echo number_format($classPrices['Class 1'], 2); ?></td> <!-- Format price to 2 decimals -->
                <td><?php echo array_sum($class1Counts); ?></td>
                <td><?php echo number_format($classTotals['Class 1'], 2); ?></td>
            </tr>
            <tr>
                <td>Class 2</td>
                <td><?php echo number_format($classPrices['Class 2'], 2); ?></td> <!-- Format price to 2 decimals -->
                <td><?php echo array_sum($class2Counts); ?></td>
                <td><?php echo number_format($classTotals['Class 2'], 2); ?></td>
            </tr>
            <tr>
                <td>Class 3</td>
                <td><?php echo number_format($classPrices['Class 3'], 2); ?></td> <!-- Format price to 2 decimals -->
                <td><?php echo array_sum($class3Counts); ?></td>
                <td><?php echo number_format($classTotals['Class 3'], 2); ?></td>
            </tr>
            <tr>
                <td>Class 4</td>
                <td><?php echo number_format($classPrices['Class 4'], 2); ?></td> <!-- Format price to 2 decimals -->
                <td><?php echo array_sum($class4Counts); ?></td>
                <td><?php echo number_format($classTotals['Class 4'], 2); ?></td>
            </tr>
            <tr>
                <td>Class 5</td>
                <td><?php echo number_format($classPrices['Class 5'], 2); ?></td> <!-- Format price to 2 decimals -->
                <td><?php echo array_sum($class5Counts); ?></td>
                <td><?php echo number_format($classTotals['Class 5'], 2); ?></td>
            </tr>

            <!-- Total Row -->
            <tr class="total-row">
                <td><strong>Total</strong></td>
                <td></td>
                <td><strong><?php echo $totalVehicles; ?></strong></td>
                <td><strong><?php echo number_format($totalPrice, 2); ?></strong></td>
            </tr>
        </tbody>
    </table>

    <script>
        // Prepare data for the chart
        const days = <?php echo json_encode($days); ?>;
        const class1Counts = <?php echo json_encode($class1Counts); ?>;
        const class2Counts = <?php echo json_encode($class2Counts); ?>;
        const class3Counts = <?php echo json_encode($class3Counts); ?>;
        const class4Counts = <?php echo json_encode($class4Counts); ?>;
        const class5Counts = <?php echo json_encode($class5Counts); ?>;

        // Create the bar chart using Chart.js
        const ctx = document.getElementById('monthlyChart').getContext('2d');
        const monthlyChart = new Chart(ctx, {
            type: 'bar', // Set type to 'bar' for bar chart
            data: {
                labels: days,  // Days of the month
                datasets: [
                    {
                        label: 'Class 1',
                        data: class1Counts,
                        backgroundColor: 'rgba(0, 128, 0, 0.6)', // Green
                        stack: 'Stack 0',
                        borderColor: 'rgba(0, 128, 0, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Class 2',
                        data: class2Counts,
                        backgroundColor: 'rgba(255, 255, 0, 0.6)', // Yellow
                        stack: 'Stack 0',
                        borderColor: 'rgba(255, 255, 0, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Class 3',
                        data: class3Counts,
                        backgroundColor: 'rgba(255, 0, 0, 0.6)', // Red
                        stack: 'Stack 0',
                        borderColor: 'rgba(255, 0, 0, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Class 4',
                        data: class4Counts,
                        backgroundColor: 'rgba(255, 165, 0, 0.6)', // Orange
                        stack: 'Stack 0',
                        borderColor: 'rgba(255, 165, 0, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Class 5',
                        data: class5Counts,
                        backgroundColor: 'rgba(128, 128, 128, 0.6)', // Grey
                        stack: 'Stack 0',
                        borderColor: 'rgba(128, 128, 128, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Days'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Vehicles'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                responsive: true,
                scales: {
                    x: {
                        stacked: true,
                    },
                    y: {
                        stacked: true,
                    }
                }
            }
        });
    </script>
</body>
</html>
