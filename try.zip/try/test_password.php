<?php
$password_input = 'saru'; // Input password
$stored_hash = '$2y$10$epbrIwSutBZ...'; // Replace this with the hash in your database

if (password_verify($password_input, $stored_hash)) {
    echo "Password matches!";
} else {
    echo "Password does NOT match!";
}
?>
