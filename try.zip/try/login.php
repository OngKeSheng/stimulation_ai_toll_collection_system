<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header('Content-Type: application/json');

// Connect to database
$conn = new mysqli('localhost', 'root', '', 'tollcollectionsystem');

// Check connection
if ($conn->connect_error) {
    echo json_encode(["success" => false, "error" => "Database connection failed"]);
    exit();
}

// Decode input JSON
$data = json_decode(file_get_contents('php://input'), true);

// Validate inputs
if (!isset($data['email']) || !isset($data['password'])) {
    echo json_encode(["success" => false, "error" => "Invalid input data"]);
    exit();
}

// Retrieve data
$email = $data['email'];
$password = $data['password'];

// Query to find email
$sql = "SELECT * FROM admin WHERE admin_email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    // Debug Logs
    error_log("Email Found: " . $row['admin_email']);
    error_log("Stored Hash: " . $row['admin_password']);
    error_log("Input Password: " . $password);

    // Verify password
    if (password_verify($password, $row['admin_password'])) {
        echo json_encode(["success" => true]);
        error_log("Login Successful!");
    } else {
        echo json_encode(["success" => false, "error" => "Invalid password"]);
        error_log("Password Mismatch!");
    }
} else {
    echo json_encode(["success" => false, "error" => "Email not registered"]);
    error_log("Email Not Found!");
}

// Close connection
$stmt->close();
$conn->close();
?>
