import numpy as np
import tkinter as tk
from tkinter import filedialog, Label, ttk
from PIL import Image, ImageTk
from tensorflow.keras.models import load_model
import cv2 as cv
from gtts import gTTS
import pygame
import threading
import os
import pymysql

# Load the trained model
model = load_model("trained_model.h5")

# Class names and prices
class_data = {
    "Class 1": 1.00,
    "Class 2": 4.60,
    "Class 3": 6.90,
    "Class 4": 1.20,
    "Class 5": 1.60,
}
class_names = list(class_data.keys())

# Initialize pygame mixer
pygame.mixer.init()

# Database connection
def connect_to_db():
    try:
        conn = pymysql.connect(
            host="localhost",
            user="root",  # Change to your MySQL username
            password="",  # Change to your MySQL password
            database="tollcollectionsystem"
        )
        return conn
    except pymysql.MySQLError as err:
        print(f"Error: {err}")
        return None

# Fetch joined detection data
def fetch_vehicle_detection_data():
    try:
        conn = connect_to_db()
        if conn is None:
            return []
        cursor = conn.cursor()
        query = """
            SELECT 
                d.detection_id,
                DATE(d.timestamp) AS date,
                TIME(d.timestamp) AS time,
                d.class_id,
                c.class_price,
                d.confidence
            FROM 
                detection d
            JOIN 
                class c ON d.class_id = c.class_id;
        """
        cursor.execute(query)
        data = cursor.fetchall()
        conn.close()
        # Correctly format confidence as a percentage
        formatted_data = [
            (
                d[0],  # detection_id
                d[1],  # date
                d[2],  # time
                d[3],  # class_id
                f"RM{float(d[4]):.2f}",  # class_price
                f"{round(float(d[5]) * 100, 2):.2f}%"  # confidence converted to percentage and rounded
            )
            for d in data
        ]
        return formatted_data
    except pymysql.MySQLError as err:
        print(f"Error: {err}")
        return []


# Insert detection data into the detection table
def insert_detection_data(class_id, confidence):
    try:
        conn = connect_to_db()
        if conn is None:
            return
        cursor = conn.cursor()
        query = """
            INSERT INTO detection (class_id, confidence)
            VALUES (%s, %s);
        """
        cursor.execute(query, (class_id, confidence))
        conn.commit()
        conn.close()
    except pymysql.MySQLError as err:
        print(f"Error: {err}")

# Preprocess the image for the model
def preprocess_image(image_path, img_size=(64, 64)):
    image = cv.imread(image_path)
    if image is None:
        print("Could not read the image.")
        return None
    image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
    image = cv.resize(image, img_size)
    image = image / 255.0
    return np.expand_dims(image, axis=0)

# Function to play sound
def play_sound(class_label):
    pygame.mixer.init()
    sound_files = {
        "Class 1": "vehicle_class_one_announcement.mp3",
        "Class 2": "vehicle_class_two_announcement.mp3",
        "Class 3": "vehicle_class_three_announcement.mp3",
        "Class 4": "vehicle_class_four_announcement.mp3",
        "Class 5": "vehicle_class_five_announcement.mp3",
    }
    sound_file = sound_files.get(class_label)
    if sound_file:
        pygame.mixer.music.load(sound_file)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            continue  # Wait until the music finishes playing

# Classify the image and display the result
def classify_image():
    file_path = filedialog.askopenfilename()
    if not file_path:
        return

    processed_image = preprocess_image(file_path)
    if processed_image is None:
        result_label.config(text="Error loading image.")
        return

    predictions = model.predict(processed_image)
    class_index = np.argmax(predictions)
    class_label = class_names[class_index]
    confidence = np.max(predictions)
    price = class_data[class_label]

    # Insert data into the database
    insert_detection_data(class_label, confidence)

    result_label.config(
        text=f"Predicted: {class_label} ({confidence * 100:.2f}%)\nPrice: RM{price:.2f}"
    )

    image = Image.open(file_path)
    image = image.resize((200, 200))
    img = ImageTk.PhotoImage(image)
    img_label.config(image=img)
    img_label.image = img

    threading.Thread(target=lambda: play_sound(class_label)).start()

    # Refresh table data after insertion
    refresh_vehicle_detection_table()

# Display the vehicle detection data in the GUI in ascending order (by detection_id or date)
def display_vehicle_detection_data():
    vehicle_data = fetch_vehicle_detection_data()

    # Sort the data by detection_id (or any other column like date)
    vehicle_data.sort(key=lambda x: x[0])  # Sort by detection_id in ascending order

    # Insert rows with alternating row colors
    for index, row in enumerate(vehicle_data):
        detection_id, date, time, class_id, class_price, accuracy = row
        
        row_tag = "evenrow" if index % 2 == 0 else "oddrow"  # Alternate row colors
        user_table.insert("", tk.END, values=(detection_id, date, time, class_id, class_price, accuracy), tags=(row_tag,))

# Refresh vehicle detection table with sorted data
def refresh_vehicle_detection_table():
    for row in user_table.get_children():
        user_table.delete(row)
    display_vehicle_detection_data()

# Initialize the GUI
root = tk.Tk()
root.title("Vehicle Classifier")

open_button = tk.Button(root, text="Select Image", command=classify_image)
open_button.pack()

img_label = Label(root)
img_label.pack()

result_label = Label(root, text="Select an image to classify", font=("Arial", 14))
result_label.pack()

# Vehicle detection data table display
user_table = ttk.Treeview(root, columns=("ID", "Date", "Time", "Class", "Price", "Accuracy"), show="headings")

# Set column headings
user_table.heading("ID", text="ID")
user_table.heading("Date", text="Date")
user_table.heading("Time", text="Time")
user_table.heading("Class", text="Class")
user_table.heading("Price", text="Price (RM)")
user_table.heading("Accuracy", text="Accuracy (%)")

# Adjust column width and align text for better readability
user_table.column("ID", width=50, anchor="center")
user_table.column("Date", width=100, anchor="center")
user_table.column("Time", width=100, anchor="center")
user_table.column("Class", width=100, anchor="center")
user_table.column("Price", width=100, anchor="center")
user_table.column("Accuracy", width=120, anchor="center")

# Set font and row height for better appearance
user_table.tag_configure("evenrow", background="#f9f9f9")  # Light gray background for even rows
user_table.tag_configure("oddrow", background="#ffffff")  # White background for odd rows

# Create a scrollbar for the table
scrollbar = ttk.Scrollbar(root, orient="vertical", command=user_table.yview)
scrollbar.pack(side="right", fill="y")
user_table.configure(yscrollcommand=scrollbar.set)

# Pack the table to the window
user_table.pack()

# Populate the table with vehicle detection data
display_vehicle_detection_data()

root.mainloop()
