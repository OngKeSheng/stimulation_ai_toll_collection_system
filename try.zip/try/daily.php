<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: lightblue;
        .chart-container {
            width: 80%;
            margin: 0 auto;
        }
        .back-button {
            position: absolute;
            top: 10px;
            left: 10px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            text-align: center;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        .total-row {
            font-weight: bold;
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <!-- Back Button -->
    <a href="http://localhost/try/model.html" class="back-button">Back</a>

    <h1 style="text-align: center;">Daily Report</h1>

     <!-- Dropdown for selecting report type -->
    <form method="GET" action="http://localhost/try/daily.php" style="text-align: center; margin-bottom: 20px;">
        <label for="reportType">Report Type:</label>
        <select name="reportType" id="reportType" onchange="navigateToReport()">
            <option value="daily" selected>Daily</option>
            <option value="weekly" >Weekly</option>
            <option value="monthly">Monthly</option>
        </select>
        <button type="submit" id="navigateButton">Enter</button>
    </form>

    <script>
        function navigateToReport() {
            const reportType = document.getElementById('reportType').value;
            const button = document.getElementById('navigateButton');

            if (reportType === 'daily') {
                // Redirect to daily.php
                button.form.action = "http://localhost/try/daily.php";
            } else if (reportType === 'weekly') {
                // Redirect to weekly.php
                button.form.action = "http://localhost/try/weekly.php";
            } else if (reportType === 'monthly') {
                // Redirect to monthly.php
                button.form.action = "http://localhost/try/monthly.php";
            }
        }
    </script>

    <!-- Dropdown for selecting year, month, and day -->
    <form method="POST" style="text-align: center; margin-bottom: 20px;">
        <label for="year">Year:</label>
        <select name="year" id="year">
            <option value="2024" <?php echo isset($_POST['year']) && $_POST['year'] == '2024' ? 'selected' : ''; ?>>2024</option>
            <option value="2025" <?php echo isset($_POST['year']) && $_POST['year'] == '2025' ? 'selected' : ''; ?>>2025</option>
        </select>

        <label for="month">Month:</label>
        <select name="month" id="month" onchange="populateDays()">
            <option value="01" <?php echo isset($_POST['month']) && $_POST['month'] == '01' ? 'selected' : ''; ?>>January</option>
            <option value="12" <?php echo isset($_POST['month']) && $_POST['month'] == '12' ? 'selected' : ''; ?>>December</option>
        </select>

        <label for="day">Day:</label>
        <select name="day" id="day">
            <?php 
            $selectedDay = isset($_POST['day']) ? $_POST['day'] : 1;
            for ($i = 1; $i <= 31; $i++) {
                echo "<option value='$i' " . ($i == $selectedDay ? 'selected' : '') . ">$i</option>";
            }
            ?>
        </select>

        <button type="submit" name="submit">Generate Report</button>
    </form>

    <div class="chart-container">
        <canvas id="dailyChart"></canvas>
    </div>

    <?php
    // Set default values if no form submission
    if (isset($_POST['submit'])) {
        // Get selected year, month, and day
        $year = $_POST['year'];
        $month = $_POST['month'];
        $day = $_POST['day'];
        $date = "$year-$month-$day";
    } else {
        // Default to the first day of January 2024
        $year = "2024";
        $month = "01";
        $day = "01";
        $date = "$year-$month-$day";
    }

    // Database connection
    $conn = new mysqli("localhost", "root", "", "tollcollectionsystem");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch hourly report data for the selected date
    $sql = "SELECT HOUR(d.timestamp) AS hour, 
                   COUNT(d.detection_id) AS vehicle_count, 
                   SUM(CASE WHEN c.class_id = 'Class 1' THEN 1 ELSE 0 END) AS class_1_count,
                   SUM(CASE WHEN c.class_id = 'Class 2' THEN 1 ELSE 0 END) AS class_2_count,
                   SUM(CASE WHEN c.class_id = 'Class 3' THEN 1 ELSE 0 END) AS class_3_count,
                   SUM(CASE WHEN c.class_id = 'Class 4' THEN 1 ELSE 0 END) AS class_4_count,
                   SUM(CASE WHEN c.class_id = 'Class 5' THEN 1 ELSE 0 END) AS class_5_count
            FROM detection d
            INNER JOIN class c ON d.class_id = c.class_id
            WHERE DATE(d.timestamp) = '$date'
            GROUP BY HOUR(d.timestamp)
            ORDER BY hour";

    $result = $conn->query($sql);

    // Initialize data arrays for graph
    $hours = [];
    $class1Counts = [];
    $class2Counts = [];
    $class3Counts = [];
    $class4Counts = [];
    $class5Counts = [];
    $classPrices = [
        'Class 1' => 1,
        'Class 2' => 4.6,
        'Class 3' => 6.9,
        'Class 4' => 1.2,
        'Class 5' => 1.6
    ];

    // Populate data arrays
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $hours[] = sprintf("%02d:00-%02d:00", $row['hour'], ($row['hour'] + 1) % 24);
            $class1Counts[] = $row['class_1_count'];
            $class2Counts[] = $row['class_2_count'];
            $class3Counts[] = $row['class_3_count'];
            $class4Counts[] = $row['class_4_count'];
            $class5Counts[] = $row['class_5_count'];
        }
    }

    $conn->close();

    // Calculate totals for the table
    $classTotals = [
        'Class 1' => array_sum($class1Counts) * $classPrices['Class 1'],
        'Class 2' => array_sum($class2Counts) * $classPrices['Class 2'],
        'Class 3' => array_sum($class3Counts) * $classPrices['Class 3'],
        'Class 4' => array_sum($class4Counts) * $classPrices['Class 4'],
        'Class 5' => array_sum($class5Counts) * $classPrices['Class 5']
    ];
    $totalVehicles = array_sum($class1Counts) + array_sum($class2Counts) + array_sum($class3Counts) + array_sum($class4Counts) + array_sum($class5Counts);
    $totalFee = array_sum($classTotals);
    ?>
    <!-- Display the table -->
    <table>
        <thead>
            <tr>
                <th>Class Type</th>
                <th>Class Price (RM)</th>
                <th>Vehicle Number</th>
                <th>Total Fee (RM)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($classPrices as $class => $price) { ?>
                <tr>
                    <td><?php echo $class; ?></td>
                    <td><?php echo number_format($price, 2); ?></td>
                    <td><?php echo array_sum(${"class" . substr($class, -1) . "Counts"}); ?></td>
                    <td><?php echo number_format($classTotals[$class], 2); ?></td>
                </tr>
            <?php } ?>
            <tr class="total-row">
                <td><strong>Total</strong></td>
                <td></td>
                <td><strong><?php echo $totalVehicles; ?></strong></td>
                <td><strong><?php echo number_format($totalFee, 2); ?></strong></td>
            </tr>
        </tbody>
    </table>
        <script>
        // Prepare data for the chart
        const hours = <?php echo json_encode($hours); ?>;
        const class1Counts = <?php echo json_encode($class1Counts); ?>;
        const class2Counts = <?php echo json_encode($class2Counts); ?>;
        const class3Counts = <?php echo json_encode($class3Counts); ?>;
        const class4Counts = <?php echo json_encode($class4Counts); ?>;
        const class5Counts = <?php echo json_encode($class5Counts); ?>;

        // Create the stacked bar chart
        const ctx = document.getElementById('dailyChart').getContext('2d');
        const dailyChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: hours,
                datasets: [
                    {
                        label: 'Class 1',
                        data: class1Counts,
                        backgroundColor: 'rgba(0, 128, 0, 0.6)', // Green
                        stack: 'Stack 0',
                        borderColor: 'rgba(0, 128, 0, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Class 2',
                        data: class2Counts,
                        backgroundColor: 'rgba(255, 255, 0, 0.6)', // Yellow
                        stack: 'Stack 0',
                        borderColor: 'rgba(255, 255, 0, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Class 3',
                        data: class3Counts,
                        backgroundColor: 'rgba(255, 0, 0, 0.6)', // Red
                        stack: 'Stack 0',
                        borderColor: 'rgba(255, 0, 0, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Class 4',
                        data: class4Counts,
                        backgroundColor: 'rgba(255, 165, 0, 0.6)', // Orange
                        stack: 'Stack 0',
                        borderColor: 'rgba(255, 165, 0, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Class 5',
                        data: class5Counts,
                        backgroundColor: 'rgba(128, 128, 128, 0.6)', // Grey
                        stack: 'Stack 0',
                        borderColor: 'rgba(128, 128, 128, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                scales: {
                    x: {
                        stacked: true,
                        title: {
                            display: true,
                            text: 'Hours'
                        }
                    },
                    y: {
                        stacked: true,
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Vehicles'
                        },
                        ticks: {
                            stepSize: 1,
                            callback: function(value) {
                                if (Number.isInteger(value)) {
                                    return value;
                                }
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                responsive: true
            }
        });

    </script>
</body>
</html>
