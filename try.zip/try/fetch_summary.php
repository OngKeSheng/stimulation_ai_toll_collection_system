<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "tollcollectionsystem");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT SUM(c.class_price) AS total_price, COUNT(*) AS total_records
        FROM detection d
        INNER JOIN class c ON d.class_id = c.class_id"
        ORDER BY d.detection_id ASC";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo \"<p>Total Records: \" . $row['total_records'] . \"</p>\";
    echo \"<p>Total Price: \" . number_format($row['total_price'], 2) . \"</p>\";
} else {
    echo \"<p>Total Records: 0</p>\";
    echo \"<p>Total Price: 0.00</p>\";
}

$conn->close();
?>
