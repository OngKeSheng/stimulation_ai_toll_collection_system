<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "tollcollectionsystem");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT d.detection_id, DATE(d.timestamp) AS date, TIME(d.timestamp) AS time, 
            (d.confidence * 100) AS accuracy, d.class_id, c.class_price
        FROM detection d
        INNER JOIN class c ON d.class_id = c.class_id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo \"<tr>\"
            . \"<td>\" . $row['detection_id'] . \"</td>\"
            . \"<td>\" . $row['date'] . \"</td>\"
            . \"<td>\" . $row['time'] . \"</td>\"
            . \"<td>\" . number_format($row['accuracy'], 2) . \"</td>\"
            . \"<td>\" . $row['class_id'] . \"</td>\"
            . \"<td>\" . number_format($row['class_price'], 2) . \"</td>\"
            . \"</tr>\";
    }
} else {
    echo \"<tr><td colspan='6'>No records found</td></tr>\";
}

$conn->close();
?>
