<?php
// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json");

// Path to Python script
$command = 'python C:\\xampp\\htdocs\\try\\CHECK_PIC.py'; // Adjust the path if necessary

// Execute the script and capture the output
exec($command, $output, $return_var);

// Handle output
if ($return_var === 0) {
    echo json_encode(["status" => "success", "output" => implode("\n", $output)]);
} else {
    echo json_encode(["status" => "error", "message" => "Script execution failed"]);
}
?>
