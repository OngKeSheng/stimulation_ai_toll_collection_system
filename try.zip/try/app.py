from flask import Flask, request, jsonify, render_template
import subprocess
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('model.html')

@app.route('/check_pic', methods=['POST'])
def check_pic():
    try:
        # Get uploaded file
        file = request.files['file']
        if file:
            # Save the file temporarily
            filepath = os.path.join('uploads', file.filename)
            file.save(filepath)

            # Call Python script with the selected image
            result = subprocess.run(['python', 'CHECK_PIC.py', filepath],
                                    capture_output=True, text=True)

            # Return output
            return jsonify({'output': result.stdout})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '_main_':
    app.run(debug=True)