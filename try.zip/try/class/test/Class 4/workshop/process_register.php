<?php
include 'db_connect.php'; // Include database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password for security

    // Validate fields
    if (!empty($username) && !empty($email) && !empty($password)) {
        // Insert data into the admin table
        $sql = "INSERT INTO admin (admin_username, admin_email, admin_password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $username, $email, $password);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful!'); window.location.href='testhtml.html';</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "'); window.location.href='testhtml.html';</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('All fields are required!'); window.location.href='testhtml.html';</script>";
    }
}

$conn->close();
?>
