// Select elements
const registerLink = document.querySelector('.register-link');
const loginForm = document.querySelector('.form-box.login');
const registerForm = document.querySelector('.form-box.register');

// Add event listener to the "Register" link
registerLink.addEventListener('click', () => {
    loginForm.style.display = 'none'; // Hide login form
    registerForm.style.display = 'block'; // Show registration form
});