<?php
$host = "localhost"; // Database host (usually localhost for local development)
$username = "root";  // Database username
$password = "";      // Database password (leave blank for XAMPP/WAMP default)
$dbname = "tollcollectionsystem"; // Your database name

// Create a connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
