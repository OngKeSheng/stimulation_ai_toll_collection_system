<?php
echo password_hash('saru', PASSWORD_BCRYPT);
?>
