import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Conv2D, MaxPooling2D, Flatten, Dropout
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from imutils import paths
import cv2 as cv
import os

# Load images from a specified folder
ImagePaths = list(paths.list_images('class'))

# Function to load images and resize them
def load_images(image_paths, resize_dim=(64, 64)):
    images = []
    valid_paths = []
    for path in image_paths:
        image = cv.imread(path)  # Attempt to read each individual image file
        if image is None:
            print(f"Warning: Unable to load image at path: {path}")
            continue  # Skip to the next image if loading fails
        # Convert to RGB and resize
        image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
        image = cv.resize(image, resize_dim)
        images.append(image)
        valid_paths.append(path)  # Add only successful paths
    return np.array(images), valid_paths

# Function to assign labels based on directory structure
def assign_labels(image_paths):
    labels = []
    for path in image_paths:
        # Use os.path to handle directory separators for both Windows and Unix-based systems
        label = os.path.basename(os.path.dirname(path))
        labels.append(label)
    return np.array(labels)

# Split dataset into training and testing sets
train_paths, test_paths = train_test_split(ImagePaths, test_size=0.2, random_state=0)
print(f"Number of training images: {len(train_paths)}")
print(f"Number of testing images: {len(test_paths)}")

# Load images and assign labels
x_train, valid_train_paths = load_images(train_paths)
y_train = assign_labels(valid_train_paths)
x_test, valid_test_paths = load_images(test_paths)
y_test = assign_labels(valid_test_paths)

# Encode labels to integer format
label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(y_train)
y_test = label_encoder.transform(y_test)

# Normalize pixel values
x_train = x_train / 255.0
x_test = x_test / 255.0

# Build the CNN model
model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(64, 64, 3)),
    MaxPooling2D((2, 2)),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D((2, 2)),
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D((2, 2)),
    Flatten(),
    Dense(128, activation='relu'),
    Dropout(0.65),
    Dense(64, activation='relu'),
    Dropout(0.3),
    Dense(len(label_encoder.classes_), activation='softmax')  # Adjust output units to number of classes
])

# Compile the model
model.compile(optimizer=Adam(learning_rate=0.001), 
              loss='sparse_categorical_crossentropy', 
              metrics=['accuracy'])

# Display model architecture
model.summary()

# Train the model
history = model.fit(x_train, y_train, batch_size=32, epochs=100, validation_split=0.3, verbose=1)

# Plot training and validation loss
plt.plot(history.history['loss'], label='Training loss')
plt.plot(history.history['val_loss'], label='Validation loss')
plt.legend()
plt.show()

# Evaluate the model
test_loss, test_accuracy = model.evaluate(x_test, y_test)
print(f"Test Accuracy: {test_accuracy * 100:.2f}%")

# Save the trained model as .h5 file
model.save("trained_model.h5")
print("Model saved as 'trained_model.h5'")

# To load the model later:
# loaded_model = load_model("trained_model.h5")
