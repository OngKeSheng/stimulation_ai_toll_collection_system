<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header('Content-Type: application/json');

// Connect to database
$conn = new mysqli('localhost', 'root', '', 'tollcollectionsystem');

// Check connection
if ($conn->connect_error) {
    echo json_encode(["success" => false, "error" => "Database connection failed"]);
    exit();
}

// Decode input JSON
$data = json_decode(file_get_contents('php://input'), true);

// Validate inputs
if (!isset($data['username']) || !isset($data['email']) || !isset($data['password'])) {
    echo json_encode(["success" => false, "error" => "Invalid input data"]);
    exit();
}

// Collect data
$username = $data['username'];
$email = $data['email'];
$password = password_hash($data['password'], PASSWORD_BCRYPT); // Hash password

// Check if email already exists
$check_email = "SELECT * FROM admin WHERE admin_email=?";
$stmt = $conn->prepare($check_email);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    echo json_encode(["success" => false, "error" => "Email already exists"]);
    exit();
}

// Insert data into database
$sql = "INSERT INTO admin (admin_username, admin_email, admin_password) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $username, $email, $password);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => "Failed to register"]);
}

$stmt->close();
$conn->close();
?>
