import sys
import os
import numpy as np
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
from tensorflow.keras.models import load_model
import cv2 as cv
from ultralytics import YOLO
import pymysql
import pygame
import time
from decimal import Decimal
import datetime

# Suppress YOLO output by redirecting stdout
class suppress_stdout_stderr:
    def __init__(self):
        self.null = open(os.devnull, 'w')
        self.old_stdout = sys.stdout
        self.old_stderr = sys.stderr

    def __enter__(self):
        sys.stdout = self.null
        sys.stderr = self.null

    def __exit__(self, exc_type, exc_value, traceback):
        sys.stdout = self.old_stdout
        sys.stderr = self.old_stderr

# Load the trained classification model
model = load_model("trained_model.h5")

# Class names and prices
class_names = ["Class 1", "Class 2", "Class 3", "Class 4", "Class 5"]
class_data = {
    "Class 1": 1.00,  # Cars
    "Class 2": 4.60,  # Vans/lorries with 4 tires
    "Class 3": 6.90,  # Lorries with 6 tires/trailers
    "Class 4": 1.20,  # Taxis
    "Class 5": 1.60,  # Buses
}

# Load YOLO model
yolo_model = YOLO("yolov8n.pt")
yolo_model.verbose = False  # Suppress verbose logging from YOLO

# Initialize pygame mixer
pygame.mixer.init()

# State variables
hold_active = False
hold_end_time = None
snap_frame = None
snap_classification = None

# Database connection
def connect_to_db():
    try:
        conn = pymysql.connect(
            host="localhost",
            user="root",  # Replace with your MySQL username
            password="",  # Replace with your MySQL password
            database="tollcollectionsystem"
        )
        return conn
    except pymysql.MySQLError as err:
        print(f"Error: {err}")
        return None

# Insert detection data into the database
def insert_detection_data(class_id, confidence):
    try:
        conn = connect_to_db()
        if conn is None:
            print("Database connection failed.")
            return
        cursor = conn.cursor()
        query = """
            INSERT INTO detection (class_id, confidence, timestamp)
            VALUES (%s, %s, NOW());
        """
        cursor.execute(query, (class_id, confidence))
        conn.commit()
        print("Record inserted successfully.")
    except pymysql.MySQLError as err:
        print(f"Error during insertion: {err}")
    finally:
        if conn:
            conn.close()

def fetch_vehicle_detection_data():
    try:
        # Connect to the database
        connection = pymysql.connect(
            host='localhost',
            user='root',  # Replace with your MySQL username
            password='',  # Replace with your MySQL password
            database='tollcollectionsystem'
        )
        with connection.cursor() as cursor:
            # Fetch data with a JOIN query
            query = """
                SELECT detection.detection_id, detection.timestamp, detection.confidence, 
                       detection.class_id, class.class_price
                FROM detection
                JOIN class ON detection.class_id = class.class_id
                ORDER BY detection.detection_id ASC
            """
            cursor.execute(query)
            records = cursor.fetchall()
        
        # Close the connection
        connection.close()

        # Print the fetched records for debugging
        print(f"Fetched records: {records}")

        # Process and format the records
        processed_records = []
        for row in records:
            detection_id, timestamp, confidence, class_id, class_price = row
            
            # Format the timestamp to separate date and time
            formatted_datetime = timestamp.strftime('%Y-%m-%d %H:%M:%S')
            date, time = formatted_datetime.split()  # Split into date and time

            # Append the processed record to the list
            processed_records.append((detection_id, date, time, class_id, class_price, confidence))

        return processed_records

    except Exception as e:
        print(f"Error during data fetch: {e}")
        return []


# Display the vehicle detection data in the GUI in ascending order (by detection_id)
def display_vehicle_detection_data():
    vehicle_data = fetch_vehicle_detection_data()

    # Sort the data by detection_id (or any other column like date)
    vehicle_data.sort(key=lambda x: x[0])  # Sort by detection_id in ascending order

    # Insert rows with alternating row colors
    for index, row in enumerate(vehicle_data):
        detection_id, date, time, class_id, class_price, confidence = row  # Adjusted to include class_price
        
        # Format class_price to 2 decimal points with "RM" prefix
        formatted_class_price = f"RM {Decimal(class_price):.2f}"

        # Convert confidence to percentage and format to 2 decimal points
        formatted_confidence = f"{confidence * 100:.2f}"

        row_tag = "evenrow" if index % 2 == 0 else "oddrow"  # Alternate row colors
        user_table.insert(
            "", tk.END,
            values=(detection_id, date, time, class_id, formatted_class_price, formatted_confidence),
            tags=(row_tag,)
        )

# Refresh vehicle detection table with sorted data
def refresh_vehicle_detection_table():
    for row in user_table.get_children():
        user_table.delete(row)
    display_vehicle_detection_data()

# Preprocess frame for the classification model
def preprocess_frame(frame, img_size=(64, 64)):
    frame = cv.resize(frame, img_size)
    frame = frame / 255.0  # Normalize to [0, 1]
    return np.expand_dims(frame, axis=0)

# Function to detect vehicles using YOLO
def detect_vehicles(frame):
    with suppress_stdout_stderr():  # Suppress YOLO's debug output
        results = yolo_model(frame)
    detections = []

    for result in results[0].boxes.data:
        x1, y1, x2, y2, confidence, class_id = result[:6]
        class_id = int(class_id)
        label = yolo_model.names[class_id]

        if label in ["car", "truck", "bus", "motorbike", "taxi"]:
            detections.append({
                "bbox": (int(x1), int(y1), int(x2), int(y2)),
                "confidence": float(confidence),
                "label": label,
            })

    return detections

# Adjust classification based on YOLO output and known class rules
def map_classification(yolo_label, class_label):
    if yolo_label == "car":
        return "Class 1"
    elif yolo_label in ["truck", "van"]:
        return "Class 2"
    elif yolo_label == "truck" and class_label == "Class 3":
        return "Class 3"
    elif yolo_label == "taxi":
        return "Class 4"
    elif yolo_label == "bus":
        return "Class 5"
    return class_label  # Default to the model's prediction

# Function to play sound based on classification
def play_sound(class_label):
    sound_files = {
        "Class 1": "vehicle_class_one_announcement.mp3",
        "Class 2": "vehicle_class_two_announcement.mp3",
        "Class 3": "vehicle_class_three_announcement.mp3",
        "Class 4": "vehicle_class_four_announcement.mp3",
        "Class 5": "vehicle_class_five_announcement.mp3",
    }
    pygame.mixer.music.stop()
    sound_file = sound_files.get(class_label)
    if sound_file:
        pygame.mixer.music.load(sound_file)
        pygame.mixer.music.play()
    else:
        print(f"Sound file for {class_label} not found!")

# Function to update the GUI and handle snapping
def update_frame():
    global hold_active, hold_end_time, snap_frame, snap_classification

    if hold_active:
        remaining_time = max(0, hold_end_time - time.time())
        if remaining_time == 0:
            hold_active = False
        result_label.config(text=snap_classification)
        countdown_label.config(text=f"Holding for {remaining_time:.1f}s")
        frame_rgb = cv.cvtColor(snap_frame, cv.COLOR_BGR2RGB)
        img = Image.fromarray(frame_rgb)
        img = img.resize((400, 300))
        imgtk = ImageTk.PhotoImage(image=img)
        img_label.config(image=imgtk)
        img_label.image = imgtk
        root.after(10, update_frame)
        return

    ret, frame = cap.read()
    if not ret:
        result_label.config(text="Failed to capture video frame.")
        root.after(10, update_frame)
        return

    detections = detect_vehicles(frame)
    if not detections:
        result_label.config(text="No vehicle detected.")
        countdown_label.config(text="")
    else:
        detection = max(detections, key=lambda d: d["confidence"])
        (x1, y1, x2, y2) = detection["bbox"]
        yolo_label = detection["label"]

        vehicle_region = frame[max(0, y1):y2, max(0, x1):x2]
        processed_frame = preprocess_frame(vehicle_region)

        predictions = model.predict(processed_frame)
        class_index = np.argmax(predictions)
        class_label = class_names[class_index]
        confidence = np.max(predictions) * 100

        mapped_class_label = map_classification(yolo_label, class_label)

        price = class_data[mapped_class_label]

        snap_frame = frame.copy()
        snap_classification = (
            f"YOLO Detected: {yolo_label}\n"
            f"Classification: {mapped_class_label} ({confidence:.2f}%)\n"
            f"Price: RM{price:.2f}"
        )

        play_sound(mapped_class_label)

        # Insert detection into the database
        insert_detection_data(mapped_class_label, confidence / 100.0)

        # Refresh the table to show the latest record
        refresh_vehicle_detection_table()

        hold_active = True
        hold_end_time = time.time() + 5

    frame_rgb = cv.cvtColor(frame, cv.COLOR_BGR2RGB)
    img = Image.fromarray(frame_rgb)
    img = img.resize((400, 300))
    imgtk = ImageTk.PhotoImage(image=img)
    img_label.config(image=imgtk)
    img_label.image = imgtk
    root.after(10, update_frame)

# Create the main window
root = tk.Tk()
root.title("Vehicle Detection System")

# Video capture (replace with your camera source)
cap = cv.VideoCapture(0)

# Create a frame for the GUI layout
frame = tk.Frame(root)
frame.pack()

# Image display
img_label = tk.Label(frame)
img_label.grid(row=0, column=0)

# Result label
result_label = tk.Label(frame, text="Waiting for vehicle detection...", font=("Arial", 14))
result_label.grid(row=1, column=0)

# Countdown label
countdown_label = tk.Label(frame, text="", font=("Arial", 12))
countdown_label.grid(row=2, column=0)

# Table for displaying vehicle detection data
table_frame = tk.Frame(root)
table_frame.pack()

user_table = ttk.Treeview(table_frame, columns=("detection_id", "date", "time", "class_id", "class_price", "accuracy"), show="headings")
user_table.pack()

user_table.heading("detection_id", text="Detection ID")
user_table.heading("date", text="Date")
user_table.heading("time", text="Time")
user_table.heading("class_id", text="Class ID")
user_table.heading("class_price", text="Class Price (RM)")
user_table.heading("accuracy", text="Confidence (%)")

user_table.tag_configure("evenrow", background="lightgrey")
user_table.tag_configure("oddrow", background="white")

display_vehicle_detection_data()

root.after(10, update_frame)

root.mainloop()
