<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detection Records</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 18px;
            text-align: left;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 12px;
        }
        th {
            background-color: #f2f2f2;
        }
        .summary {
            margin: 20px 0;
            font-size: 18px;
            font-weight: bold;
        }
        .delete-box {
            margin-top: 20px;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <h1>Detection Records</h1>

    <!-- Sorting Controls -->
    <form method="GET" class="sort-controls">
        <label for="sort_column">Sort By:</label>
        <select name="sort_column" id="sort_column">
            <option value="detection_id" <?php echo isset($_GET['sort_column']) && $_GET['sort_column'] == 'detection_id' ? 'selected' : ''; ?>>ID</option>
            <option value="timestamp" <?php echo isset($_GET['sort_column']) && $_GET['sort_column'] == 'timestamp' ? 'selected' : ''; ?>>Date</option>
            <option value="confidence" <?php echo isset($_GET['sort_column']) && $_GET['sort_column'] == 'confidence' ? 'selected' : ''; ?>>Accuracy</option>
            <option value="class_id" <?php echo isset($_GET['sort_column']) && $_GET['sort_column'] == 'class_id' ? 'selected' : ''; ?>>Class</option>
        </select>

        <label>
            <input type="radio" name="sort_order" value="ASC" <?php echo isset($_GET['sort_order']) && $_GET['sort_order'] == 'ASC' ? 'checked' : ''; ?> /> Ascending
        </label>
        <label>
            <input type="radio" name="sort_order" value="DESC" <?php echo isset($_GET['sort_order']) && $_GET['sort_order'] == 'DESC' ? 'checked' : ''; ?> /> Descending
        </label>

        <button type="submit">Sort</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Time</th>
                <th>Accuracy (%)</th>
                <th>Class</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Database connection
            $conn = new mysqli("localhost", "root", "", "tollcollectionsystem");

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Handle deletion
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_id'])) {
                $delete_id = intval($_POST['delete_id']); // Sanitize input
                $delete_query = "DELETE FROM detection WHERE detection_id = $delete_id";
                if ($conn->query($delete_query) === TRUE) {
                    echo "<p style='color: green;'>Record with ID $delete_id successfully deleted.</p>";
                } else {
                    echo "<p style='color: red;'>Error deleting record: " . $conn->error . "</p>";
                }
            }

            // Get sorting inputs from the form
            $sort_column = isset($_GET['sort_column']) ? $_GET['sort_column'] : 'detection_id';
            $sort_order = isset($_GET['sort_order']) && $_GET['sort_order'] === 'DESC' ? 'DESC' : 'ASC';

            // Validate column name to prevent SQL injection
            $valid_columns = ['detection_id', 'timestamp', 'confidence', 'class_id'];
            if (!in_array($sort_column, $valid_columns)) {
                $sort_column = 'detection_id';
            }

            // Query with sorting
            $sql = "SELECT d.detection_id, DATE(d.timestamp) AS date, TIME(d.timestamp) AS time, 
                        (d.confidence * 100) AS accuracy, d.class_id, c.class_price
                    FROM detection d
                    INNER JOIN class c ON d.class_id = c.class_id
                    ORDER BY $sort_column $sort_order";

            $result = $conn->query($sql);
            $total_price = 0;
            $total_records = 0;

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $total_price += $row['class_price'];
                    $total_records++;
                    echo "<tr>"
                        . "<td>" . $row['detection_id'] . "</td>"
                        . "<td>" . $row['date'] . "</td>"
                        . "<td>" . $row['time'] . "</td>"
                        . "<td>" . number_format($row['accuracy'], 2) . "</td>"
                        . "<td>" . $row['class_id'] . "</td>"
                        . "<td>" . number_format($row['class_price'], 2) . "</td>"
                        . "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No records found</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>

    <div class="summary">
        <p>Total Records: <?php echo $total_records; ?></p>
        <p>Total Price: <?php echo number_format($total_price, 2); ?></p>
    </div>

    <!-- Delete Record Form -->
    <div class="delete-box">
        <form method="POST">
            <label for="delete_id">Delete ID:</label>
            <input type="number" id="delete_id" name="delete_id" required>
            <button type="submit">Delete</button>
        </form>
    </div>
</body>
</html>
